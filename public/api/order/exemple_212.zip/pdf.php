<?php
	// подключаем шрифты
		define('FPDF_FONTPATH',"fpdf/font/");
	// подключаем библиотеку
		require('fpdf/fpdf.php');

	// создаем PDF документ
		$pdf=new FPDF();
	// устанавливаем заголовок документа
		$pdf->SetTitle("kakorin.com test pdf");

	// создаем страницу
		$pdf->AddPage('P');
		$pdf->SetDisplayMode(real,'default');
		
	// добавляем шрифт ариал
		$pdf->AddFont('Arial','','arial.php'); 
	// устанавливаем шрифт Ариал
		$pdf->SetFont('Arial');
	// устанавливаем цвет шрифта
		$pdf->SetTextColor(250,60,100);
	// устанавливаем размер шрифта
		$pdf->SetFontSize(10);

	// добавляем текст
		$pdf->SetXY(10,10);
		$pdf->Write(0,iconv('utf-8', 'windows-1251',"Коммерческое предложение"));

	// добавляем на страницу изображение    
		$pdf->Image(dirname(__FILE__) .'/logo.jpg', 100, 250, 100, 49, 'JPG');
		
	// выводим документа в браузере
	   $pdf->Output('iskspb.ru.pdf','I');